from django.db import models

# Create your models here.


class books(models.Model):
    bookname=models.CharField(max_length=100)
    modifieddate=models.DateTimeField(auto_now=True)
    