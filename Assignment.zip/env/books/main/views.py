from django.http.response import JsonResponse
from django.shortcuts import render
from .models import books
from django.template.loader import render_to_string

# Create your views here.


def index(request):
    test = int()
    updatename=''
    updateid=''
    cnnt=''
    deleteid=''
    bookname=''
    if request.method == 'POST':
        bookname=request.POST.get('bookname')
        test = request.POST.get('test')
        updatename = request.POST.get('updatename')
        updateid = request.POST.get('updateid')
        deleteid = request.POST.get('del')
        if deleteid:
            print("delete:",deleteid)
            delt = books.objects.get(id=deleteid)
            delt.delete()
        if updatename and updateid:
            change = books.objects.get(id=updateid)
            change.bookname = updatename
            change.save()
            
        if test:
            print(test)
        if bookname :    
            book=books(bookname=bookname)
            if book:
                book.save()
    
        
    cnnt = 0
    updateddata = []
    if updatename and updateid:
        changedata = books.objects.all()
        for i in changedata:
            cnnt = cnnt+1
            obj4 = {
                'count':cnnt,
                'id':i.id,
                'name':i.bookname,
                'date':i.modifieddate
            }
            updateddata.append(obj4)
        return JsonResponse({'updateddata':updateddata})
    
    if deleteid:
        count1=0
        deletedata = books.objects.all()
        for i in deletedata:
            count1 = count1+1
            obj5 = {
                'count':count1,
                'id':i.id,
                'name':i.bookname,
                'date':i.modifieddate
            }
            updateddata.append(obj5)
        return JsonResponse({'deleteddata':updateddata})
    cnt = 0
    data= []
    allbook=books.objects.all()
    for i in allbook:
        cnt= cnt +1
        obj={
            'cunt':cnt,
            'id':i.id,
            'bookname':i.bookname,
            'date':i.modifieddate
        }
         
        data.append(obj)
    
    obj3=[]
    if test:
        bk = books.objects.get(id=test)
        obj3 = {
            'name':bk.bookname
        }
        return JsonResponse({'name':obj3})
        
    context = {
        'data':data
    }
    
 
    if bookname:
        print(data)
        latestdata = books.objects.latest('id')
        numb=len(data)
        obj2 = {
            'count':numb,
            'id':latestdata.id,
            'bookname':latestdata.bookname,
            'date':latestdata.modifieddate
        }
        print("obj2",obj2)
    if request.is_ajax():
        # data= {'rendered_table':render_to_string('index.html', context=context)}
        return JsonResponse({'data':obj2})
    # for i in book:
    #     obj={
    #         'id':i.id,
    #         'bookname':i.bookname,
    #         'date':i.modifieddate
    #     }
    #     print(obj)    


    return render(request,'index.html',context)